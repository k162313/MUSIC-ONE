package com.musicone.app

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

 data class LocalAudio(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: android.net.Uri,
    val artworkUri: android.net.Uri? = null
)

object LocalAudioRepository {
    fun scan(context: Context): List<LocalAudio> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val result = mutableListOf<LocalAudio>()
        context.contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += LocalAudio(
                    id = id,
                    title = cursor.getString(titleCol) ?: "未知歌曲",
                    artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "未知艺术家",
                    album = cursor.getString(albumCol) ?: "未知专辑",
                    durationMs = cursor.getLong(durationCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    artworkUri = cursor.getLong(albumIdCol).takeIf { it > 0L }?.let { android.net.Uri.parse("content://media/external/audio/albumart/$it") }
                )
            }
        }
        return result
    }
}
