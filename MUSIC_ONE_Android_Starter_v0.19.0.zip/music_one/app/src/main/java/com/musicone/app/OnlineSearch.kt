package com.musicone.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Runs configured provider API searches away from the UI thread. */
object OnlineSearchRepository {
    suspend fun search(context: Context, keyword: String): Pair<List<OnlineTrack>, List<String>> = withContext(Dispatchers.IO) {
        val sources = SourceRepository.load(context).filter { it.enabled && !it.searchUrlTemplate.isNullOrBlank() }
        if (sources.isEmpty()) return@withContext emptyList<OnlineTrack>() to listOf("没有可搜索的音源。请导入带 searchUrlTemplate 的合法服务配置。")
        val results = mutableListOf<OnlineTrack>()
        val errors = mutableListOf<String>()
        sources.forEach { source ->
            runCatching { SourceRepository.search(source, keyword) }
                .onSuccess { results += it }
                .onFailure { errors += "${source.name}：${it.message ?: "搜索失败"}" }
        }
        results.distinctBy { it.streamUrl } to errors
    }
}
