package com.musicone.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small, versioned local library store. No account or cloud service is required. */
data class SavedTrack(
    val key: String,
    val title: String,
    val artist: String,
    val uri: String,
    val source: String = "本地音乐"
)

data class MusicPlaylist(val id: String, val name: String, val tracks: List<SavedTrack>)
data class LibraryData(
    val favorites: List<SavedTrack> = emptyList(),
    val recent: List<SavedTrack> = emptyList(),
    val playlists: List<MusicPlaylist> = emptyList(),
    val playCounts: Map<String, Int> = emptyMap()
)

object LibraryRepository {
    private const val PREFS = "music_one_library_v1"
    private const val KEY_DATA = "library_json"
    private const val MAX_LIBRARY_JSON_CHARS = 5_000_000
    private const val MAX_PLAYLISTS = 10
    private const val MAX_TRACKS_PER_PLAYLIST = 100
    private const val MAX_PLAY_COUNTS = 2_000
    private const val MAX_TRACK_FIELD_LENGTH = 512

    fun load(context: Context): LibraryData = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DATA, null)
            ?: return LibraryData()
        if (raw.length > MAX_LIBRARY_JSON_CHARS) return LibraryData()
        val root = JSONObject(raw)
        LibraryData(
            favorites = root.optJSONArray("favorites").toTracks(500),
            recent = root.optJSONArray("recent").toTracks(100),
            playlists = root.optJSONArray("playlists").toPlaylists(),
            playCounts = root.optJSONObject("playCounts").toIntMap()
        )
    }.getOrDefault(LibraryData())

    fun save(context: Context, data: LibraryData) {
        val bounded = data.copy(
            favorites = data.favorites.take(500).map { it.bounded() },
            recent = data.recent.take(100).map { it.bounded() },
            playlists = data.playlists.take(MAX_PLAYLISTS).map { playlist ->
                playlist.copy(id = playlist.id.take(128), name = playlist.name.take(40),
                    tracks = playlist.tracks.take(MAX_TRACKS_PER_PLAYLIST).map { it.bounded() })
            },
            playCounts = data.playCounts.entries.take(MAX_PLAY_COUNTS).associate { it.key.take(512) to it.value.coerceAtLeast(0) }
        )
        val root = JSONObject().put("version", 1)
            .put("favorites", bounded.favorites.toJson())
            .put("recent", bounded.recent.toJson())
            .put("playlists", bounded.playlists.toJson())
            .put("playCounts", JSONObject().also { obj -> bounded.playCounts.forEach { (key, count) -> obj.put(key, count) } })
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DATA, root.toString()).apply()
    }

    fun toggleFavorite(context: Context, data: LibraryData, track: SavedTrack): LibraryData {
        val next = if (data.favorites.any { it.key == track.key }) data.copy(favorites = data.favorites.filterNot { it.key == track.key })
        else data.copy(favorites = (listOf(track) + data.favorites).take(500))
        save(context, next)
        return next
    }

    fun recordRecent(context: Context, data: LibraryData, track: SavedTrack): LibraryData {
        val next = data.copy(
            recent = (listOf(track) + data.recent.filterNot { it.key == track.key }).take(100),
            playCounts = (data.playCounts + (track.key to ((data.playCounts[track.key] ?: 0) + 1)))
                .entries.toList().takeLast(MAX_PLAY_COUNTS).associate { it.key to it.value }
        )
        save(context, next)
        return next
    }

    fun createPlaylist(context: Context, data: LibraryData, name: String): LibraryData {
        val clean = name.trim().take(40)
        if (clean.isBlank() || data.playlists.size >= MAX_PLAYLISTS || data.playlists.any { it.name.equals(clean, ignoreCase = true) }) return data
        val next = data.copy(playlists = data.playlists + MusicPlaylist(java.util.UUID.randomUUID().toString(), clean, emptyList()))
        save(context, next)
        return next
    }

    fun addToPlaylist(context: Context, data: LibraryData, playlistId: String, track: SavedTrack): LibraryData {
        val next = data.copy(playlists = data.playlists.map { playlist ->
            if (playlist.id != playlistId || playlist.tracks.any { it.key == track.key } || playlist.tracks.size >= MAX_TRACKS_PER_PLAYLIST) playlist
            else playlist.copy(tracks = playlist.tracks + track)
        })
        save(context, next)
        return next
    }

    fun deletePlaylist(context: Context, data: LibraryData, playlistId: String): LibraryData {
        val next = data.copy(playlists = data.playlists.filterNot { it.id == playlistId })
        save(context, next)
        return next
    }

    private fun SavedTrack.bounded() = copy(
        key = key.take(512), title = title.take(MAX_TRACK_FIELD_LENGTH),
        artist = artist.take(MAX_TRACK_FIELD_LENGTH), uri = uri.take(2_048),
        source = source.take(256)
    )
    private fun JSONObject?.toIntMap(): Map<String, Int> {
        if (this == null) return emptyMap()
        return keys().asSequence().take(MAX_PLAY_COUNTS).mapNotNull { key ->
            runCatching { key.take(512) to optInt(key).coerceAtLeast(0) }.getOrNull()
        }.toMap()
    }
    private fun SavedTrack.toJson() = JSONObject().put("key", key).put("title", title)
        .put("artist", artist).put("uri", uri).put("source", source)
    private fun List<SavedTrack>.toJson() = JSONArray().also { array -> forEach { array.put(it.toJson()) } }
    private fun JSONArray?.toTracks(limit: Int): List<SavedTrack> {
        if (this == null) return emptyList()
        return (0 until minOf(length(), limit)).mapNotNull { index -> runCatching {
            getJSONObject(index).let { SavedTrack(it.getString("key").take(512), it.getString("title").take(MAX_TRACK_FIELD_LENGTH),
                it.optString("artist").take(MAX_TRACK_FIELD_LENGTH), it.optString("uri").take(2_048),
                it.optString("source", "本地音乐").take(256)) }
        }.getOrNull() }
    }
    private fun List<MusicPlaylist>.toJson() = JSONArray().also { array -> forEach { playlist ->
        array.put(JSONObject().put("id", playlist.id).put("name", playlist.name).put("tracks", playlist.tracks.toJson()))
    } }
    private fun JSONArray?.toPlaylists(): List<MusicPlaylist> {
        if (this == null) return emptyList()
        return (0 until minOf(length(), MAX_PLAYLISTS)).mapNotNull { index -> runCatching {
            getJSONObject(index).let { MusicPlaylist(it.getString("id").take(128), it.getString("name").take(40),
                it.optJSONArray("tracks").toTracks(MAX_TRACKS_PER_PLAYLIST)) }
        }.getOrNull() }
    }
}

fun LocalAudio.toSavedTrack() = SavedTrack("local:$id", title, artist, uri.toString())
fun OnlineTrack.toSavedTrack() = SavedTrack("online:$streamUrl", title, artist, streamUrl, sourceName)
