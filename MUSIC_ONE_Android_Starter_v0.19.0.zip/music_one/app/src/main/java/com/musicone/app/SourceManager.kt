package com.musicone.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

/** A deliberately data-only provider descriptor. Arbitrary JavaScript source plugins are never executed. */
data class MusicSource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val baseUrl: String,
    val pingUrl: String = baseUrl,
    /** Optional provider-owned JSON search endpoint. Use {query} as the URL-encoded keyword placeholder. */
    val searchUrlTemplate: String? = null,
    val itemsPath: String = "",
    val titleField: String = "title",
    val artistField: String = "artist",
    val streamField: String = "url",
    /** Optional dot path to an HTTPS album-art URL in each search result. */
    val artworkField: String = "artwork",
    /** Optional provider-owned JSON lyric endpoint. Supports {query}, {title}, and {artist}. */
    val lyricUrlTemplate: String? = null,
    /** Dot path to the LRC/plain lyric text in the JSON response. */
    val lyricField: String = "lyric",
    val enabled: Boolean = true,
    val latencyMs: Long? = null,
    val status: String = "未检测"
)

object SourceRepository {
    private const val PREFS = "music_one_sources"
    private const val KEY = "sources"
    private const val MAX_SOURCES = 100
    private const val MAX_IMPORT_CHARS = 1_000_000
    private const val MAX_CONFIG_FIELD = 512

    fun load(context: Context): List<MusicSource> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        if (raw.length > MAX_IMPORT_CHARS) return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until minOf(array.length(), MAX_SOURCES)).mapNotNull { i -> runCatching { fromJson(array.getJSONObject(i)) }.getOrNull() }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, sources: List<MusicSource>) {
        val array = JSONArray()
        sources.take(MAX_SOURCES).forEach { s -> array.put(JSONObject().put("id", s.id.take(128)).put("name", s.name.take(80)).put("baseUrl", s.baseUrl.take(2048))
            .put("pingUrl", s.pingUrl.take(2048)).put("searchUrlTemplate", s.searchUrlTemplate?.take(4096)).put("itemsPath", s.itemsPath.take(MAX_CONFIG_FIELD))
            .put("titleField", s.titleField.take(MAX_CONFIG_FIELD)).put("artistField", s.artistField.take(MAX_CONFIG_FIELD)).put("streamField", s.streamField.take(MAX_CONFIG_FIELD)).put("artworkField", s.artworkField.take(MAX_CONFIG_FIELD))
            .put("lyricUrlTemplate", s.lyricUrlTemplate?.take(4096)).put("lyricField", s.lyricField.take(MAX_CONFIG_FIELD)).put("enabled", s.enabled).put("latencyMs", s.latencyMs ?: JSONObject.NULL).put("status", s.status.take(128))) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    /** Accepts MUSIC ONE's documented JSON format, including arrays. Unknown executable/plugin fields are ignored. */
    fun importJson(context: Context, json: String): List<MusicSource> {
        require(json.length <= MAX_IMPORT_CHARS) { "音源配置文件过大" }
        val parsed = mutableListOf<MusicSource>()
        fun add(o: JSONObject) {
            val name = o.optString("name", o.optString("title", "")).trim()
            val base = o.optString("baseUrl", o.optString("url", "")).trim()
            val ping = o.optString("pingUrl", base).trim()
            val searchTemplate = o.optString("searchUrlTemplate", "").trim().ifBlank { null }
            val itemsPath = o.optString("itemsPath", "")
            val titleField = o.optString("titleField", "title")
            val artistField = o.optString("artistField", "artist")
            val streamField = o.optString("streamField", "url")
            val artworkField = o.optString("artworkField", "artwork")
            val lyricTemplate = o.optString("lyricUrlTemplate", "").trim().ifBlank { null }
            val lyricTemplateSafe = lyricTemplate == null || (
                (lyricTemplate.contains("{query}") || lyricTemplate.contains("{title}")) &&
                isSafeHttpUrl(lyricTemplate.replace("{query}", "test").replace("{title}", "test").replace("{artist}", "test"))
            )
            val templateSafe = searchTemplate == null || (searchTemplate.contains("{query}") &&
                isSafeHttpUrl(searchTemplate.replace("{query}", "test")))
            val fieldsBounded = listOf(itemsPath, titleField, artistField, streamField, artworkField, o.optString("lyricField", "lyric"))
                .all { it.length <= MAX_CONFIG_FIELD }
            if (name.isNotBlank() && base.length <= 2048 && ping.length <= 2048 &&
                (searchTemplate?.length ?: 0) <= 4096 && (lyricTemplate?.length ?: 0) <= 4096 &&
                fieldsBounded && isSafeHttpUrl(base) && isSafeHttpUrl(ping) && templateSafe && lyricTemplateSafe) {
                parsed += MusicSource(name = name.take(80), baseUrl = base, pingUrl = ping,
                    searchUrlTemplate = searchTemplate, itemsPath = itemsPath,
                    titleField = titleField, artistField = artistField, streamField = streamField, artworkField = artworkField,
                    lyricUrlTemplate = lyricTemplate, lyricField = o.optString("lyricField", "lyric"))
                if (parsed.size >= MAX_SOURCES) return
            }
        }
        when {
            json.trimStart().startsWith("[") -> { val a = JSONArray(json); for (i in 0 until a.length()) if (a.opt(i) is JSONObject) add(a.getJSONObject(i)) }
            json.trimStart().startsWith("{") -> {
                val root = JSONObject(json)
                val arr = root.optJSONArray("sources") ?: root.optJSONArray("providers")
                if (arr != null) {
                    for (i in 0 until arr.length()) { if (arr.opt(i) is JSONObject) add(arr.getJSONObject(i)) }
                } else add(root)
            }
            else -> throw IllegalArgumentException("文件不是有效的 JSON")
        }
        if (parsed.isEmpty()) throw IllegalArgumentException("没有找到可识别的音源。请确认包含 name 和 https 的 baseUrl 字段。")
        val existing = load(context)
        val importedUrls = parsed.mapTo(mutableSetOf()) { it.baseUrl }
        // Put newly imported/replaced entries first so a full source list can still accept updates.
        val result = (parsed + existing.filterNot { it.baseUrl in importedUrls })
            .distinctBy { it.baseUrl }.take(MAX_SOURCES)
        save(context, result)
        return result
    }

    /** Remember the most recently successful provider so later searches can prefer it. */
    fun rememberSuccessfulSource(context: Context, sourceName: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("last_successful_source", sourceName).apply()
    }

    /** Rank alternatives by last-known success, then measured latency, then import order. */
    fun rankForPlayback(context: Context, tracks: List<OnlineTrack>): List<OnlineTrack> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val preferred = prefs.getString("last_successful_source", null)
        val sources = load(context).associateBy { it.name }
        return tracks.distinctBy { it.streamUrl }.sortedWith(
            compareBy<OnlineTrack> { if (it.sourceName == preferred) 0 else 1 }
                .thenBy { sources[it.sourceName]?.latencyMs ?: Long.MAX_VALUE }
        )
    }

    fun isSafeHttpUrl(value: String): Boolean = runCatching {
        val u = URL(value)
        (u.protocol == "https") && !u.host.isNullOrBlank() && u.userInfo == null
    }.getOrDefault(false)

    fun check(source: MusicSource, done: (MusicSource) -> Unit) {
        thread(name = "source-health-check") {
            val start = System.nanoTime()
            val result = runCatching {
                val connection = (URL(source.pingUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000; readTimeout = 5000; requestMethod = "GET"; instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "MUSIC-ONE/0.3")
                }
                try {
                    val code = connection.responseCode
                    // Do not accept redirects: an imported HTTPS endpoint must not silently
                    // redirect the app to an untrusted or clear-text destination.
                    if (code !in 200..299) error("HTTP $code")
                    // Drain only a tiny prefix: some health endpoints accidentally return
                    // their full HTML/API payload even though we only need the status code.
                    connection.inputStream.use { stream ->
                        val buffer = ByteArray(1024)
                        var remaining = 4096
                        while (remaining > 0) {
                            val read = stream.read(buffer, 0, minOf(buffer.size, remaining))
                            if (read <= 0) break
                            remaining -= read
                        }
                    }
                    val ms = (System.nanoTime() - start) / 1_000_000
                    source.copy(latencyMs = ms, status = "可用")
                } finally { connection.disconnect() }
            }.getOrElse { source.copy(latencyMs = null, status = "不可用：${it.message?.take(40) ?: "连接失败"}") }
            done(result)
        }
    }

    /** Search only explicitly configured, provider-owned JSON APIs. No arbitrary plugin code is executed. */
    fun search(source: MusicSource, keyword: String): List<OnlineTrack> {
        val template = source.searchUrlTemplate ?: error("该音源尚未配置在线搜索接口")
        require(template.contains("{query}")) { "搜索地址缺少 {query} 占位符" }
        val encoded = java.net.URLEncoder.encode(keyword, "UTF-8")
        val endpoint = template.replace("{query}", encoded)
        require(isSafeHttpUrl(endpoint)) { "搜索地址必须使用 HTTPS" }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000; requestMethod = "GET"
            instanceFollowRedirects = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "MUSIC-ONE/0.4")
        }
        val body = try {
            val code = connection.responseCode
            if (code !in 200..299) error("搜索接口返回 HTTP $code")
            connection.inputStream.use { readTextLimited(it, 2_000_000) }
        } finally { connection.disconnect() }
        val root = org.json.JSONTokener(body).nextValue()
        var node: Any? = root
        source.itemsPath.split('.').filter { it.isNotBlank() }.forEach { key ->
            node = when (val current = node) {
                is JSONObject -> current.opt(key)
                is JSONArray -> key.toIntOrNull()?.let { current.opt(it) }
                else -> null
            }
        }
        val array = when (node) {
            is JSONArray -> node as JSONArray
            is JSONObject -> JSONArray().put(node)
            else -> if (root is JSONArray && source.itemsPath.isBlank()) root else JSONArray()
        }
        buildList {
            for (i in 0 until minOf(array.length(), 100)) {
                val item = array.optJSONObject(i) ?: continue
                val title = readPath(item, source.titleField)?.toString()?.trim().orEmpty()
                val artist = readPath(item, source.artistField)?.toString()?.trim().orEmpty()
                val stream = readPath(item, source.streamField)?.toString()?.trim().orEmpty()
                val artwork = readPath(item, source.artworkField)?.toString()?.trim()?.takeIf { isSafeHttpUrl(it) }
                if (title.isNotBlank() && isSafeHttpUrl(stream)) add(OnlineTrack(title, artist.ifBlank { "未知歌手" }, stream, source.name, artwork))
            }
        }
    }

    /** Read a response with a hard character limit instead of loading an unbounded body first. */
    private fun readTextLimited(input: java.io.InputStream, maxBytes: Int): String {
        val output = java.io.ByteArrayOutputStream(minOf(maxBytes, 16_384))
        val buffer = ByteArray(8_192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > maxBytes) error("服务响应过大，已停止读取")
            output.write(buffer, 0, count)
        }
        return output.toString(Charsets.UTF_8.name())
    }

    private fun readPath(obj: JSONObject, path: String): Any? {
        var value: Any? = obj
        path.split('.').filter { it.isNotBlank() }.forEach { key ->
            value = when (val current = value) {
                is JSONObject -> current.opt(key)
                is JSONArray -> key.toIntOrNull()?.let { current.opt(it) }
                else -> null
            }
        }
        return value?.takeUnless { it == JSONObject.NULL }
    }

    /** Fetch lyrics only from an explicitly configured HTTPS endpoint belonging to an imported provider. */
    fun fetchLyrics(source: MusicSource, title: String, artist: String): String? {
        val template = source.lyricUrlTemplate ?: return null
        val encodedTitle = java.net.URLEncoder.encode(title, "UTF-8")
        val encodedArtist = java.net.URLEncoder.encode(artist, "UTF-8")
        val endpoint = template.replace("{query}", java.net.URLEncoder.encode("$title $artist", "UTF-8"))
            .replace("{title}", encodedTitle).replace("{artist}", encodedArtist)
        require(isSafeHttpUrl(endpoint)) { "歌词接口必须使用 HTTPS" }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000; readTimeout = 8000; requestMethod = "GET"
            instanceFollowRedirects = false
            setRequestProperty("Accept", "application/json,text/plain")
            setRequestProperty("User-Agent", "MUSIC-ONE/0.8")
        }
        val body = try {
            val code = connection.responseCode
            if (code !in 200..299) error("歌词接口返回 HTTP $code")
            connection.inputStream.use { readTextLimited(it, 1_000_000) }
        } finally { connection.disconnect() }
        val text = runCatching {
            val root = org.json.JSONTokener(body).nextValue()
            var node: Any? = root
            source.lyricField.split('.').filter { it.isNotBlank() }.forEach { key ->
                node = when (val current = node) {
                    is JSONObject -> current.opt(key)
                    is JSONArray -> key.toIntOrNull()?.let { current.opt(it) }
                    else -> null
                }
            }
            when (node) {
                is String -> node as String
                is JSONObject -> (node as JSONObject).optString("text", "")
                else -> ""
            }
        }.getOrElse { if (body.trimStart().startsWith("[") || body.trimStart().startsWith("{")) "" else body }
        return text.takeIf { it.isNotBlank() && it.length <= 500_000 }
    }

    fun recommended(sources: List<MusicSource>): MusicSource? = sources.filter { it.enabled && it.status == "可用" }
        .minByOrNull { it.latencyMs ?: Long.MAX_VALUE }

    private fun fromJson(o: JSONObject) = MusicSource(
        id = o.optString("id", UUID.randomUUID().toString()), name = o.getString("name"),
        baseUrl = o.getString("baseUrl"), pingUrl = o.optString("pingUrl", o.getString("baseUrl")),
        searchUrlTemplate = o.optString("searchUrlTemplate", "").ifBlank { null },
        itemsPath = o.optString("itemsPath", ""), titleField = o.optString("titleField", "title"),
        artistField = o.optString("artistField", "artist"), streamField = o.optString("streamField", "url"),
        lyricUrlTemplate = o.optString("lyricUrlTemplate", "").ifBlank { null }, lyricField = o.optString("lyricField", "lyric"),
        enabled = o.optBoolean("enabled", true),
        latencyMs = if (o.isNull("latencyMs")) null else o.optLong("latencyMs"), status = o.optString("status", "未检测")
    )
}

/** A resolved, provider-authorized stream returned by a configured API. */
data class OnlineTrack(val title: String, val artist: String, val streamUrl: String, val sourceName: String, val artworkUrl: String? = null)
