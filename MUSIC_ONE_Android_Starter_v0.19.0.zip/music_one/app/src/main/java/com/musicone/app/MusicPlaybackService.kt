package com.musicone.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import org.json.JSONArray
import org.json.JSONObject

/** Owns the player and media session so playback can continue after the UI is closed. */
class MusicPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val checkpoint = object : Runnable {
        override fun run() {
            player?.let { savePlaybackState(it) }
            if (player?.isPlaying == true) handler.postDelayed(this, CHECKPOINT_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val playbackPlayer = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.DEFAULT, true)
            setHandleAudioBecomingNoisy(true)
            addListener(object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = savePlaybackState(this@apply)
                override fun onPlaybackStateChanged(playbackState: Int) = savePlaybackState(this@apply)
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    handler.removeCallbacks(checkpoint)
                    savePlaybackState(this@apply)
                    if (isPlaying) handler.postDelayed(checkpoint, CHECKPOINT_INTERVAL_MS)
                }
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = savePlaybackState(this@apply)
                override fun onRepeatModeChanged(repeatMode: Int) = savePlaybackState(this@apply)
                override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) = savePlaybackState(this@apply)
            })
        }
        player = playbackPlayer
        restorePlaybackState(playbackPlayer)
        val openPlayerIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        mediaSession = MediaSession.Builder(this, playbackPlayer)
            .setSessionActivity(openPlayerIntent)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        player?.let { savePlaybackState(it) }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(checkpoint)
        player?.let { savePlaybackState(it) }
        mediaSession?.release()
        mediaSession = null
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun savePlaybackState(exoPlayer: ExoPlayer) {
        val preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        // An explicitly cleared queue must clear its checkpoint too; otherwise an old
        // queue would unexpectedly reappear the next time the service is created.
        if (exoPlayer.mediaItemCount == 0) {
            preferences.edit().remove(KEY_STATE).apply()
            return
        }
        runCatching {
            val items = JSONArray()
            val savedOriginalIndices = mutableListOf<Int>()
            val itemCount = minOf(exoPlayer.mediaItemCount, MAX_SAVED_QUEUE_ITEMS)
            for (index in 0 until itemCount) {
                val item = exoPlayer.getMediaItemAt(index)
                val uri = item.localConfiguration?.uri?.toString()?.takeIf { it.isNotBlank() && it.length <= MAX_SAVED_URI_LENGTH }
                    ?: continue
                val metadata = item.mediaMetadata
                items.put(JSONObject()
                    .put("mediaId", item.mediaId.take(MAX_SAVED_TEXT_LENGTH))
                    .put("uri", uri)
                    .put("title", metadata.title?.toString().orEmpty().take(MAX_SAVED_TEXT_LENGTH))
                    .put("artist", metadata.artist?.toString().orEmpty().take(MAX_SAVED_TEXT_LENGTH))
                    .put("album", metadata.albumTitle?.toString().orEmpty().take(MAX_SAVED_TEXT_LENGTH))
                    .put("artwork", metadata.artworkUri?.toString().orEmpty().take(MAX_SAVED_URI_LENGTH)))
                savedOriginalIndices += index
            }
            if (items.length() == 0) {
                preferences.edit().remove(KEY_STATE).apply()
                return@runCatching
            }
            val state = JSONObject()
                .put("version", 1)
                .put("items", items)
                .put("index", (savedOriginalIndices.indexOf(exoPlayer.currentMediaItemIndex)
                    .takeIf { it >= 0 } ?: 0).coerceIn(0, items.length() - 1))
                .put("position", exoPlayer.currentPosition.coerceAtLeast(0L))
                .put("shuffle", exoPlayer.shuffleModeEnabled)
                .put("repeat", exoPlayer.repeatMode)
            preferences.edit().putString(KEY_STATE, state.toString()).apply()
        }
    }

    private fun restorePlaybackState(exoPlayer: ExoPlayer) {
        runCatching {
            val raw = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_STATE, null) ?: return
            // SharedPreferences may contain stale or externally corrupted data. Bound both
            // the serialized payload and the number/size of entries before building a queue.
            if (raw.length > MAX_SAVED_STATE_LENGTH) return
            val state = JSONObject(raw)
            val jsonItems = state.optJSONArray("items") ?: return
            if (jsonItems.length() == 0 || jsonItems.length() > MAX_SAVED_QUEUE_ITEMS) return
            val items = ArrayList<MediaItem>(jsonItems.length())
            val savedIndices = mutableListOf<Int>()
            for (index in 0 until jsonItems.length()) {
                val saved = jsonItems.optJSONObject(index) ?: continue
                val uri = saved.optString("uri").takeIf { it.isNotBlank() && it.length <= MAX_SAVED_URI_LENGTH } ?: continue
                val artwork = saved.optString("artwork").takeIf { it.isNotBlank() && it.length <= MAX_SAVED_URI_LENGTH }
                val metadata = MediaMetadata.Builder()
                    .setTitle(saved.optString("title").take(MAX_SAVED_TEXT_LENGTH))
                    .setArtist(saved.optString("artist").take(MAX_SAVED_TEXT_LENGTH))
                    .setAlbumTitle(saved.optString("album").take(MAX_SAVED_TEXT_LENGTH))
                    .apply { artwork?.let { setArtworkUri(android.net.Uri.parse(it)) } }
                    .build()
                items += MediaItem.Builder()
                    .setMediaId(saved.optString("mediaId", uri).take(MAX_SAVED_TEXT_LENGTH))
                    .setUri(uri)
                    .setMediaMetadata(metadata)
                    .build()
                savedIndices += index
            }
            if (items.isEmpty()) return
            val requestedSavedIndex = state.optInt("index", 0).coerceAtLeast(0)
            val restoredIndex = savedIndices.indexOf(requestedSavedIndex)
                .takeIf { it >= 0 }
                ?: savedIndices.indexOfFirst { it >= requestedSavedIndex }.takeIf { it >= 0 }
                ?: 0
            val position = state.optLong("position", 0L).coerceAtLeast(0L)
            exoPlayer.setMediaItems(items, restoredIndex, position)
            exoPlayer.shuffleModeEnabled = state.optBoolean("shuffle", false)
            exoPlayer.repeatMode = state.optInt("repeat", Player.REPEAT_MODE_OFF).let { savedMode ->
                if (savedMode in Player.REPEAT_MODE_OFF..Player.REPEAT_MODE_ALL) savedMode else Player.REPEAT_MODE_OFF
            }
            // Prepare the restored queue but do not unexpectedly resume audio on app launch.
            exoPlayer.prepare()
        }
    }

    private companion object {
        const val PREFS_NAME = "music_one_playback_v1"
        const val KEY_STATE = "playback_state"
        const val CHECKPOINT_INTERVAL_MS = 5_000L
        const val MAX_SAVED_QUEUE_ITEMS = 500
        const val MAX_SAVED_TEXT_LENGTH = 512
        const val MAX_SAVED_URI_LENGTH = 8_192
        const val MAX_SAVED_STATE_LENGTH = 5_000_000
    }
}
