package com.musicone.app

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

/** A single timestamped LRC lyric line. */
data class LyricLine(val timeMs: Long, val text: String)

object LrcParser {
    private val timestamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]")

    /** Parses standard LRC timestamps, including centiseconds and milliseconds. */
    fun parse(content: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        content.lineSequence().forEach lineLoop@ { raw ->
            val matches = timestamp.findAll(raw).toList()
            if (matches.isEmpty()) return@lineLoop
            val text = timestamp.replace(raw, "").trim()
            matches.forEach matchLoop@ { match ->
                val minutes = match.groupValues[1].toLongOrNull() ?: return@matchLoop
                val seconds = match.groupValues[2].toLongOrNull() ?: return@matchLoop
                if (seconds >= 60) return@matchLoop
                val fraction = match.groupValues[3]
                val millis = when (fraction.length) {
                    1 -> (fraction.toLongOrNull() ?: 0L) * 100L
                    2 -> (fraction.toLongOrNull() ?: 0L) * 10L
                    3 -> fraction.toLongOrNull() ?: 0L
                    else -> 0L
                }
                result += LyricLine((minutes * 60_000L) + (seconds * 1_000L) + millis, text)
            }
        }
        return result.sortedBy { it.timeMs }
    }
}

/** Timeline helpers: positive offset makes lyrics appear earlier; negative makes them later. */
object LrcTimeline {
    fun activeIndex(lines: List<LyricLine>, playbackPositionMs: Long, offsetMs: Long = 0L): Int =
        lines.indexOfLast { it.timeMs <= (playbackPositionMs + offsetMs).coerceAtLeast(0L) }

    fun playbackPositionForLine(line: LyricLine, offsetMs: Long = 0L): Long =
        (line.timeMs - offsetMs).coerceAtLeast(0L)
}

/** Device-local lyric cache keyed by normalized title + artist. */
object LyricCache {
    private const val PREFS = "music_one_lyrics_v1"

    fun get(context: Context, title: String, artist: String): String? = runCatching {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(cacheKey(title, artist), null)
    }.getOrNull()

    fun put(context: Context, title: String, artist: String, content: String) {
        if (content.isBlank() || content.length > 500_000) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(cacheKey(title, artist), content).apply()
    }

    private fun cacheKey(title: String, artist: String): String {
        val normalized = "${title.trim().lowercase()}|${artist.trim().lowercase()}"
        val digest = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }
}
