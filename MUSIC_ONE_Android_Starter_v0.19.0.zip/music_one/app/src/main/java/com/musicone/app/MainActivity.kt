package com.musicone.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Accent = Color(0xFFB64255)
private val Ink = Color(0xFF171719)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController by mutableStateOf<MediaController?>(null)
    private var playerUiRevision by mutableIntStateOf(0)
    private var activeOnlineTrack: OnlineTrack? = null
    private val attemptedOnlineUrls = linkedSetOf<String>()
    private var localTracks by mutableStateOf<List<LocalAudio>>(emptyList())
    private var permissionGranted by mutableStateOf(false)
    private var scanMessage by mutableStateOf("扫描手机中的音乐文件")
    private var sources by mutableStateOf<List<MusicSource>>(emptyList())
    private var sourceMessage by mutableStateOf("可导入 MUSIC ONE JSON 音源配置")
    private var onlineResults by mutableStateOf<List<OnlineTrack>>(emptyList())
    private var onlineMessage by mutableStateOf("输入歌曲名称，搜索已配置的在线音源")
    private var lyricLines by mutableStateOf<List<LyricLine>>(emptyList())
    private var lyricMessage by mutableStateOf("导入与当前歌曲匹配的 .lrc 歌词文件")
    private var libraryData by mutableStateOf(LibraryData())
    private var activeTrackTitle by mutableStateOf("")
    private var activeTrackArtist by mutableStateOf("")
    private var lyricLookupGeneration = 0

    private val lyricsPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("无法读取歌词文件")
        }.onSuccess { content ->
            val parsed = LrcParser.parse(content)
            lyricLines = parsed
            lyricMessage = if (parsed.isEmpty()) "没有识别到有效的 LRC 时间轴" else "已载入 ${parsed.size} 行歌词"
        }.onFailure { lyricMessage = it.message ?: "歌词导入失败" }
    }

    private val sourcePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("无法读取文件") }
            .onSuccess { json -> runCatching { SourceRepository.importJson(this, json) }.onSuccess { sources = it; sourceMessage = "成功导入 ${it.size} 个音源" }.onFailure { sourceMessage = it.message ?: "导入失败" } }
            .onFailure { sourceMessage = it.message ?: "读取失败" }
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) scanLocalAudio() else scanMessage = "需要允许访问音频文件，才能读取本地音乐。"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED
        sources = SourceRepository.load(this)
        libraryData = LibraryRepository.load(this)
        connectPlaybackService()
        setContent {
            MusicOneApp(
                playerStateVersion = playerUiRevision,
                tracks = localTracks,
                scanMessage = scanMessage,
                isPlaying = mediaController?.isPlaying == true,
                currentTitle = mediaController?.mediaMetadata?.title?.toString() ?: "尚未播放",
                currentArtist = mediaController?.mediaMetadata?.artist?.toString() ?: "",
                currentArtwork = mediaController?.mediaMetadata?.artworkUri?.toString(),
                durationMs = mediaController?.duration?.takeIf { it > 0L } ?: 0L,
                shuffleEnabled = mediaController?.shuffleModeEnabled == true,
                repeatMode = mediaController?.repeatMode ?: Player.REPEAT_MODE_OFF,
                queueItems = mediaController?.let { controller -> (0 until controller.mediaItemCount).map { index ->
                    val metadata = controller.getMediaItemAt(index).mediaMetadata
                    (metadata.title?.toString().orEmpty().ifBlank { "未知歌曲" }) to metadata.artist?.toString().orEmpty()
                } } ?: emptyList(),
                onSeekTo = { position -> mediaController?.seekTo(position) },
                onToggleShuffle = { mediaController?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } },
                onCycleRepeat = { mediaController?.let { it.repeatMode = when (it.repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE; Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL; else -> Player.REPEAT_MODE_OFF } } },
                onJumpToQueueItem = { index -> mediaController?.seekToDefaultPosition(index); mediaController?.play() },
                onScan = { if (permissionGranted) scanLocalAudio() else permissionLauncher.launch(audioPermission) },
                onPlayTrack = { index -> playTrack(index) },
                onTogglePlayback = { mediaController?.let { if (it.isPlaying) it.pause() else it.play() } },
                onNext = { mediaController?.seekToNextMediaItem() },
                onPrevious = { mediaController?.seekToPreviousMediaItem() },
                lyricLines = lyricLines, lyricMessage = lyricMessage,
                onImportLyrics = { lyricsPicker.launch(arrayOf("text/*", "application/octet-stream")) },
                onMatchLyrics = { matchLyricsForCurrentTrack() },
                playbackPosition = { mediaController?.currentPosition ?: 0L },
                onlineResults = onlineResults, onlineMessage = onlineMessage,
                onSearchOnline = { keyword -> searchOnline(keyword) }, onPlayOnline = { track -> playOnline(track) },
                libraryData = libraryData,
                onToggleFavorite = { track -> libraryData = LibraryRepository.toggleFavorite(this, libraryData, track) },
                onCreatePlaylist = { name -> libraryData = LibraryRepository.createPlaylist(this, libraryData, name) },
                onAddToPlaylist = { playlistId, track -> libraryData = LibraryRepository.addToPlaylist(this, libraryData, playlistId, track) },
                onDeletePlaylist = { playlistId -> libraryData = LibraryRepository.deletePlaylist(this, libraryData, playlistId) },
                onPlaySavedTrack = { saved -> playSavedTrack(saved) },
                sources = sources, sourceMessage = sourceMessage,
                onImportSource = { sourcePicker.launch(arrayOf("application/json", "text/*")) },
                onCheckSources = { checkSources() },
                onDeleteSource = { source -> sources = sources.filterNot { it.id == source.id }; SourceRepository.save(this, sources) }
            )
        }
        if (permissionGranted) scanLocalAudio()
    }

    private fun connectPlaybackService() {
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val controller = future.get()
                mediaController = controller
                controller.addListener(object : Player.Listener {
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        runOnUiThread { tryNextOnlineSource(error) }
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        runOnUiThread { playerUiRevision++ }
                        if (playbackState == Player.STATE_READY) {
                            activeOnlineTrack?.let { SourceRepository.rememberSuccessfulSource(this@MainActivity, it.sourceName) }
                        }
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { runOnUiThread { playerUiRevision++ } }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { runOnUiThread { playerUiRevision++ } }
                    override fun onRepeatModeChanged(repeatMode: Int) { runOnUiThread { playerUiRevision++ } }
                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { runOnUiThread { playerUiRevision++ } }
                })
            } catch (_: Exception) { scanMessage = "播放器初始化失败，请重新打开应用。" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanLocalAudio() {
        scanMessage = "正在扫描…"
        // MediaStore queries run off the main thread.
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) { LocalAudioRepository.scan(this@MainActivity) }
            localTracks = found
            scanMessage = if (found.isEmpty()) "没有找到本地音乐。请先将音频文件保存到手机。" else "已找到 ${found.size} 首歌曲"
        }
    }

    private fun checkSources() {
        if (sources.isEmpty()) { sourceMessage = "请先导入音源配置"; return }
        sourceMessage = "正在检测 ${sources.size} 个音源…"
        sources.forEach { source -> SourceRepository.check(source) { updated ->
            runOnUiThread {
                sources = sources.map { if (it.id == updated.id) updated else it }
                SourceRepository.save(this, sources)
                val best = SourceRepository.recommended(sources)
                sourceMessage = if (best != null) "测速完成，推荐：${best.name}（${best.latencyMs} ms）" else "检测完成，请检查不可用音源"
            }
        } }
    }

    private fun searchOnline(keyword: String) {
        if (keyword.isBlank()) { onlineMessage = "请输入歌曲名称或歌手"; onlineResults = emptyList(); return }
        onlineMessage = "正在搜索已配置的音源…"
        lifecycleScope.launch {
            val (found, errors) = OnlineSearchRepository.search(this@MainActivity, keyword.trim())
            onlineResults = SourceRepository.rankForPlayback(this@MainActivity, found)
            onlineMessage = when {
                found.isNotEmpty() -> "找到 ${found.size} 首歌曲${if (errors.isNotEmpty()) " · 部分音源搜索失败" else ""}"
                errors.isNotEmpty() -> errors.take(2).joinToString("；")
                else -> "没有找到歌曲，请检查音源配置。"
            }
        }
    }

    private fun playOnline(track: OnlineTrack) {
        val player = mediaController ?: run { onlineMessage = "播放器正在启动，请稍后再试。"; return }
        activeOnlineTrack = track
        activeTrackTitle = track.title; activeTrackArtist = track.artist
        matchLyrics(track.title, track.artist)
        libraryData = LibraryRepository.recordRecent(this, libraryData, track.toSavedTrack())
        attemptedOnlineUrls.clear()
        attemptedOnlineUrls += track.streamUrl
        startOnlineCandidate(track)
        onlineMessage = "正在使用 ${track.sourceName} 播放；失败时会尝试其他匹配音源。"
    }

    private fun startOnlineCandidate(track: OnlineTrack) {
        val player = mediaController ?: return
        val item = MediaItem.Builder().setUri(track.streamUrl)
            .setMediaId(track.streamUrl)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                .setTitle(track.title).setArtist(track.artist).setAlbumTitle("来自 ${track.sourceName}")
                .apply { track.artworkUrl?.let { setArtworkUri(android.net.Uri.parse(it)) } }.build()).build()
        activeOnlineTrack = track
        player.setMediaItem(item)
        player.prepare()
        player.play()
    }

    /** On a stream error, try another provider's result for the same track; never resolve arbitrary URLs. */
    private fun tryNextOnlineSource(error: androidx.media3.common.PlaybackException) {
        val failed = activeOnlineTrack ?: return // Local-file errors are not handled by source fallback.
        val titleKey = failed.title.trim().lowercase()
        val artistKey = failed.artist.trim().lowercase()
        val alternatives = SourceRepository.rankForPlayback(this, onlineResults).filter { candidate ->
            candidate.streamUrl !in attemptedOnlineUrls &&
                candidate.title.trim().lowercase() == titleKey &&
                (candidate.artist.trim().lowercase() == artistKey || candidate.artist.isBlank() || failed.artist.isBlank())
        }
        val next = alternatives.firstOrNull()
        if (next == null) {
            activeOnlineTrack = null
            onlineMessage = "${failed.title} 播放失败，已尝试所有匹配音源。请检查音源状态或稍后重试。"
            return
        }
        attemptedOnlineUrls += next.streamUrl
        onlineMessage = "${failed.sourceName} 播放失败，正在切换到 ${next.sourceName}…"
        startOnlineCandidate(next)
    }

    private fun playSavedTrack(saved: SavedTrack) {
        if (saved.key.startsWith("local:")) {
            val id = saved.key.removePrefix("local:").toLongOrNull()
            val index = localTracks.indexOfFirst { it.id == id }
            if (index >= 0) playTrack(index) else scanMessage = "这首本地歌曲可能已被移动或删除，请重新扫描。"
            return
        }
        val uri = runCatching { android.net.Uri.parse(saved.uri) }.getOrNull()
        if (uri?.scheme != "https") { onlineMessage = "保存的在线地址无效或不安全，请重新搜索歌曲。"; return }
        val player = mediaController ?: run { onlineMessage = "播放器正在启动，请稍后再试。"; return }
        activeOnlineTrack = null
        activeTrackTitle = saved.title; activeTrackArtist = saved.artist
        matchLyrics(saved.title, saved.artist)
        attemptedOnlineUrls.clear()
        val item = MediaItem.Builder().setUri(uri).setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
            .setTitle(saved.title).setArtist(saved.artist).setAlbumTitle(saved.source).build()).build()
        player.setMediaItem(item); player.prepare(); player.play()
        libraryData = LibraryRepository.recordRecent(this, libraryData, saved)
    }

    private fun matchLyricsForCurrentTrack() {
        if (activeTrackTitle.isBlank()) { lyricMessage = "请先播放一首歌曲"; return }
        matchLyrics(activeTrackTitle, activeTrackArtist, forceRefresh = true)
    }

    private fun matchLyrics(title: String, artist: String, forceRefresh: Boolean = false) {
        val generation = ++lyricLookupGeneration
        if (!forceRefresh) {
            val cached = LyricCache.get(this, title, artist)
            if (!cached.isNullOrBlank()) {
                val parsed = LrcParser.parse(cached)
                if (parsed.isNotEmpty()) {
                    lyricLines = parsed
                    lyricMessage = "已从本地歌词缓存匹配"
                    return
                }
            }
        }
        lyricLines = emptyList()
        lyricMessage = "正在匹配歌词…"
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val lyricSources = SourceRepository.load(this@MainActivity)
                    .filter { it.enabled && !it.lyricUrlTemplate.isNullOrBlank() }
                    .sortedBy { it.latencyMs ?: Long.MAX_VALUE }
                var matched: String? = null
                var providerName: String? = null
                for (source in lyricSources) {
                    val candidate = runCatching { SourceRepository.fetchLyrics(source, title, artist) }.getOrNull()
                    if (!candidate.isNullOrBlank() && LrcParser.parse(candidate).isNotEmpty()) {
                        matched = candidate; providerName = source.name; break
                    }
                }
                matched to providerName
            }
            if (generation != lyricLookupGeneration) return@launch
            val content = result.first
            if (content != null) {
                LyricCache.put(this@MainActivity, title, artist, content)
                lyricLines = LrcParser.parse(content)
                lyricMessage = "已从 ${result.second} 匹配并缓存歌词"
            } else {
                lyricMessage = if (SourceRepository.load(this@MainActivity).none { it.enabled && it.lyricUrlTemplate != null })
                    "没有配置歌词接口；可导入 LRC，或在音源 JSON 中配置 lyricUrlTemplate。"
                else "暂未匹配到歌词，可尝试重新匹配或导入 LRC。"
            }
        }
    }

    private fun playTrack(index: Int) {
        activeOnlineTrack = null
        attemptedOnlineUrls.clear()
        val player = mediaController ?: run { scanMessage = "播放器正在启动，请稍后再试。"; return }
        if (localTracks.isEmpty() || index !in localTracks.indices) return
        activeTrackTitle = localTracks[index].title; activeTrackArtist = localTracks[index].artist
        matchLyrics(activeTrackTitle, activeTrackArtist)
        libraryData = LibraryRepository.recordRecent(this, libraryData, localTracks[index].toSavedTrack())
        val items = localTracks.map { track ->
            MediaItem.Builder().setUri(track.uri).setMediaId(track.id.toString())
                .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(track.title).setArtist(track.artist).setAlbumTitle(track.album)
                    .apply { track.artworkUri?.let { setArtworkUri(it) } }.build()).build()
        }
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { Home("首页"), Browse("浏览"), Library("音乐库"), Me("我的") }

@Composable
private fun MusicOneApp(
    playerStateVersion: Int, tracks: List<LocalAudio>, scanMessage: String, isPlaying: Boolean, currentTitle: String, currentArtist: String,
    currentArtwork: String?, durationMs: Long, shuffleEnabled: Boolean, repeatMode: Int,
    queueItems: List<Pair<String, String>>, onSeekTo: (Long) -> Unit, onToggleShuffle: () -> Unit, onCycleRepeat: () -> Unit, onJumpToQueueItem: (Int) -> Unit,
    onScan: () -> Unit, onPlayTrack: (Int) -> Unit, onTogglePlayback: () -> Unit,
    onNext: () -> Unit, onPrevious: () -> Unit,
    lyricLines: List<LyricLine>, lyricMessage: String, onImportLyrics: () -> Unit, onMatchLyrics: () -> Unit, playbackPosition: () -> Long,
    onlineResults: List<OnlineTrack>, onlineMessage: String, onSearchOnline: (String) -> Unit, onPlayOnline: (OnlineTrack) -> Unit,
    sources: List<MusicSource>, sourceMessage: String, onImportSource: () -> Unit, onCheckSources: () -> Unit, onDeleteSource: (MusicSource) -> Unit,
    libraryData: LibraryData, onToggleFavorite: (SavedTrack) -> Unit, onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, SavedTrack) -> Unit, onDeletePlaylist: (String) -> Unit, onPlaySavedTrack: (SavedTrack) -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    var followSystem by remember { mutableStateOf(true) }
    var manualDark by remember { mutableStateOf(false) }
    val dark = if (followSystem) systemDark else manualDark
    var tab by remember { mutableStateOf(Tab.Home) }
    var showPlayer by remember { mutableStateOf(false) }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFFE58A98), background = Color(0xFF101012), surface = Color(0xFF1B1B1F))
        else lightColorScheme(primary = Accent, background = Color(0xFFF8F7F5), surface = Color.White)
    MaterialTheme(colorScheme = scheme) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
            Column {
                MiniPlayer(currentTitle, isPlaying, onTogglePlayback) { showPlayer = true }
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { tab = item },
                            icon = { Icon(when (item) { Tab.Home -> Icons.Default.Home; Tab.Browse -> Icons.Default.Explore; Tab.Library -> Icons.Default.LibraryMusic; Tab.Me -> Icons.Default.Person }, contentDescription = item.label) },
                            label = { Text(item.label) })
                    }
                }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    Tab.Home -> HomeScreen(onBrowse = { tab = Tab.Browse }, onLibrary = { tab = Tab.Library }, tracks = tracks, onPlayTrack = onPlayTrack)
                    Tab.Browse -> BrowseScreen(onlineResults, onlineMessage, onSearchOnline, onPlayOnline, libraryData, onToggleFavorite, onAddToPlaylist)
                    Tab.Library -> LibraryScreen(tracks, scanMessage, onScan, onPlayTrack, libraryData, onToggleFavorite, onCreatePlaylist, onAddToPlaylist, onDeletePlaylist, onPlaySavedTrack)
                    Tab.Me -> MeScreen(followSystem, manualDark, { followSystem = it }, { manualDark = it }, sources, sourceMessage, onImportSource, onCheckSources, onDeleteSource)
                }
            }
        }
        if (showPlayer) PlayerSheet(currentTitle, currentArtist, currentArtwork, isPlaying, onTogglePlayback, onPrevious, onNext,
            lyricLines, lyricMessage, onImportLyrics, onMatchLyrics, playbackPosition, durationMs, shuffleEnabled, repeatMode,
            queueItems, onSeekTo, onToggleShuffle, onCycleRepeat, onJumpToQueueItem) { showPlayer = false }
    }
}

@Composable
private fun HomeScreen(onBrowse: () -> Unit, onLibrary: () -> Unit, tracks: List<LocalAudio>, onPlayTrack: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Spacer(Modifier.height(22.dp)); Text("MUSIC ONE", fontSize = 13.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp)); Text("为此刻，\n播放好音乐。", fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(22.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(selected = true, onClick = {}, label = { Text("为你推荐") })
                FilterChip(selected = false, onClick = onBrowse, label = { Text("探索音乐") })
            }
            Spacer(Modifier.height(20.dp)); SectionTitle("本地音乐", "查看全部", onLibrary); Spacer(Modifier.height(8.dp))
        }
        items(tracks.take(4)) { track -> SongRow(track.title, track.artist) { onPlayTrack(tracks.indexOf(track)) } }
        if (tracks.isEmpty()) item { Text("前往「音乐库」扫描手机中的歌曲。", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
    }
}

@Composable
private fun BrowseScreen(results: List<OnlineTrack>, message: String, onSearch: (String) -> Unit, onPlay: (OnlineTrack) -> Unit, library: LibraryData, onToggleFavorite: (SavedTrack) -> Unit, onAddToPlaylist: (String, SavedTrack) -> Unit) {
    var query by remember { mutableStateOf("") }
    var pendingTrack by remember { mutableStateOf<SavedTrack?>(null) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("浏览", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("搜索歌曲或歌手") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(18.dp), singleLine = true)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onSearch(query) }, enabled = query.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Search, null); Spacer(Modifier.width(6.dp)); Text("搜索在线音乐")
        }
        Spacer(Modifier.height(14.dp))
        Text(message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        if (results.isNotEmpty()) LazyColumn {
            items(results) { track ->
                Row(Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1); Text("${track.artist} · ${track.sourceName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
                    IconButton(onClick = { onToggleFavorite(track.toSavedTrack()) }) {
                        Icon(if (library.favorites.any { it.key == track.toSavedTrack().key }) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "收藏", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { pendingTrack = track.toSavedTrack() }) { Icon(Icons.Default.PlaylistAdd, "添加到歌单") }
                    Icon(Icons.Default.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("在线搜索依赖你导入的、获准使用的音乐服务 API。", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (pendingTrack != null) AddToPlaylistDialog(library.playlists, onSelect = { id -> pendingTrack?.let { onAddToPlaylist(id, it) }; pendingTrack = null }, onDismiss = { pendingTrack = null })
}

@Composable
private fun LibraryScreen(
    tracks: List<LocalAudio>, scanMessage: String, onScan: () -> Unit, onPlayTrack: (Int) -> Unit,
    library: LibraryData, onToggleFavorite: (SavedTrack) -> Unit, onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, SavedTrack) -> Unit, onDeletePlaylist: (String) -> Unit, onPlaySavedTrack: (SavedTrack) -> Unit
) {
    var section by remember { mutableStateOf("本地") }
    var showCreate by remember { mutableStateOf(false) }
    var pendingTrack by remember { mutableStateOf<SavedTrack?>(null) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var localMode by remember { mutableStateOf("歌曲") }
    var libraryQuery by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(18.dp)); Text("音乐库", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("本地", "收藏", "最近", "常听", "歌单").forEach { label ->
                FilterChip(selected = section == label, onClick = { section = label }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        when (section) {
            "本地" -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("本地音乐", fontWeight = FontWeight.Bold); Text(scanMessage, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Button(onClick = onScan) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(5.dp)); Text("扫描") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = libraryQuery, onValueChange = { libraryQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("搜索本地歌曲、歌手或专辑") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                val visibleTracks = remember(tracks, libraryQuery) {
                    val q = libraryQuery.trim()
                    if (q.isBlank()) tracks else tracks.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("歌曲", "专辑", "歌手").forEach { mode ->
                        FilterChip(selected = localMode == mode, onClick = { localMode = mode }, label = { Text(mode) })
                    }
                }
                HorizontalDivider()
                if (visibleTracks.isEmpty()) EmptyLibraryMessage(if (libraryQuery.isBlank()) "本地还没有音乐。" else "没有找到匹配的本地音乐。")
                else when (localMode) {
                    "专辑" -> {
                        val albums = visibleTracks.groupBy { it.album.ifBlank { "未知专辑" } }.toList().sortedBy { it.first.lowercase() }
                        LazyColumn {
                            items(albums, key = { it.first }) { (album, albumTracks) ->
                                Row(Modifier.fillMaxWidth().clickable { onPlayTrack(tracks.indexOf(albumTracks.first())) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                    if (albumTracks.first().artworkUri != null) AsyncImage(model = albumTracks.first().artworkUri, contentDescription = null, modifier = Modifier.size(54.dp).clip(RoundedCornerShape(9.dp)), contentScale = ContentScale.Crop)
                                    else Box(Modifier.size(54.dp).clip(RoundedCornerShape(9.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null) }
                                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(album, fontWeight = FontWeight.SemiBold, maxLines = 1); Text("${albumTracks.first().artist} · ${albumTracks.size} 首", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
                                    Icon(Icons.Default.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                    "歌手" -> {
                        val artists = visibleTracks.groupBy { it.artist.ifBlank { "未知艺术家" } }.toList().sortedBy { it.first.lowercase() }
                        LazyColumn {
                            items(artists, key = { it.first }) { (artist, artistTracks) ->
                                Row(Modifier.fillMaxWidth().clickable { onPlayTrack(tracks.indexOf(artistTracks.first())) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null) }
                                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(artist, fontWeight = FontWeight.SemiBold); Text("${artistTracks.size} 首歌曲", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    Icon(Icons.Default.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                    else -> LazyColumn { items(visibleTracks, key = { it.id }) { track ->
                        LibrarySongRow(track.title, "${track.artist} · 播放 ${library.playCounts["local:${track.id}"] ?: 0} 次", library.favorites.any { it.key == "local:${track.id}" },
                            onPlay = { onPlayTrack(tracks.indexOf(track)) }, onFavorite = { onToggleFavorite(track.toSavedTrack()) },
                            onAdd = { pendingTrack = track.toSavedTrack() })
                    } }
                }
            }
            "收藏" -> {
                Text("已收藏 ${library.favorites.size} 首", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                if (library.favorites.isEmpty()) EmptyLibraryMessage("还没有收藏歌曲，点击歌曲旁边的爱心即可收藏。")
                else LazyColumn { items(library.favorites, key = { it.key }) { saved ->
                    LibrarySongRow(saved.title, saved.artist, true, onPlay = { onPlaySavedTrack(saved) },
                        onFavorite = { onToggleFavorite(saved) }, onAdd = { pendingTrack = saved })
                } }
            }
            "最近" -> {
                Text("最近播放 · ${library.recent.size} 首", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                if (library.recent.isEmpty()) EmptyLibraryMessage("播放过的歌曲会自动显示在这里。")
                else LazyColumn { items(library.recent, key = { it.key }) { saved ->
                    LibrarySongRow(saved.title, saved.artist, library.favorites.any { it.key == saved.key },
                        onPlay = { onPlaySavedTrack(saved) }, onFavorite = { onToggleFavorite(saved) }, onAdd = { pendingTrack = saved })
                } }
            }
            "常听" -> {
                val knownTracks = (library.recent + library.favorites + library.playlists.flatMap { it.tracks })
                    .distinctBy { it.key }
                    .sortedByDescending { library.playCounts[it.key] ?: 0 }
                    .filter { (library.playCounts[it.key] ?: 0) > 0 }
                Text("按累计播放次数排序", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                if (knownTracks.isEmpty()) EmptyLibraryMessage("播放过的歌曲会在这里按播放次数排列。")
                else LazyColumn { items(knownTracks, key = { it.key }) { saved ->
                    LibrarySongRow(saved.title, "${saved.artist} · 播放 ${library.playCounts[saved.key] ?: 0} 次",
                        library.favorites.any { it.key == saved.key }, onPlay = { onPlaySavedTrack(saved) },
                        onFavorite = { onToggleFavorite(saved) }, onAdd = { pendingTrack = saved })
                } }
            }
            else -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("我的歌单", fontWeight = FontWeight.Bold); Text("${library.playlists.size} 个歌单", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Button(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null); Text("新建") }
                }
                if (library.playlists.isEmpty()) EmptyLibraryMessage("创建歌单，把喜欢的音乐整理起来。")
                else LazyColumn { items(library.playlists, key = { it.id }) { playlist ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.QueueMusic, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(playlist.name, fontWeight = FontWeight.SemiBold); Text("${playlist.tracks.size} 首歌曲", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        IconButton(onClick = { selectedPlaylist = if (selectedPlaylist == playlist.id) null else playlist.id }) { Icon(Icons.Default.ChevronRight, "查看歌单") }
                        IconButton(onClick = { onDeletePlaylist(playlist.id) }) { Icon(Icons.Default.DeleteOutline, "删除歌单") }
                    }
                    if (selectedPlaylist == playlist.id) {
                        if (playlist.tracks.isEmpty()) Text("歌单还是空的。可在本地、收藏或最近播放中点击添加按钮。", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 46.dp, bottom = 8.dp))
                        playlist.tracks.forEach { saved -> SongRow(saved.title, saved.artist) { playSavedTrack(saved, tracks, onPlayTrack) } }
                    }
                    HorizontalDivider()
                } }
            }
        }
    }
    if (showCreate) CreatePlaylistDialog(onCreate = { name -> onCreatePlaylist(name); showCreate = false }, onDismiss = { showCreate = false })
    if (pendingTrack != null) AddToPlaylistDialog(library.playlists, onSelect = { id -> pendingTrack?.let { onAddToPlaylist(id, it) }; pendingTrack = null }, onDismiss = { pendingTrack = null })
}

@Composable
private fun EmptyLibraryMessage(message: String = "你的音乐，从这里开始。") {
    Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.LibraryMusic, null, Modifier.size(46.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp)); Text(message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LibrarySongRow(title: String, artist: String, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(9.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onPlay() }, contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null) }
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f).clickable { onPlay() }) { Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(artist, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
        IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "收藏", tint = if (favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
        IconButton(onClick = onAdd) { Icon(Icons.Default.PlaylistAdd, "添加到歌单") }
    }
}

@Composable
private fun CreatePlaylistDialog(onCreate: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("新建歌单") },
        text = { OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("歌单名称") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onCreate(name) }, enabled = name.isNotBlank()) { Text("创建") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun AddToPlaylistDialog(playlists: List<MusicPlaylist>, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("添加到歌单") },
        text = { if (playlists.isEmpty()) Text("请先在「歌单」中创建歌单。") else Column { playlists.forEach { playlist ->
            TextButton(onClick = { onSelect(playlist.id) }, modifier = Modifier.fillMaxWidth()) { Text("${playlist.name}（${playlist.tracks.size} 首）") }
        } } }, confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } })
}

@Composable
private fun MeScreen(followSystem: Boolean, manualDark: Boolean, onFollow: (Boolean) -> Unit, onDark: (Boolean) -> Unit, sources: List<MusicSource>, sourceMessage: String, onImportSource: () -> Unit, onCheckSources: () -> Unit, onDeleteSource: (MusicSource) -> Unit) {
    var showSources by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("我的", fontSize = 32.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(58.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, Modifier.size(30.dp)) }; Spacer(Modifier.width(14.dp)); Column { Text("音乐旅人", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("让喜欢的音乐随时相伴", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } }
        Spacer(Modifier.height(28.dp)); Text("设置", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth().clickable { showSources = true }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LibraryAdd, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text("音源管理", fontWeight = FontWeight.SemiBold); Text("导入、测速和管理音乐源（${sources.size}）", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        SettingsRow("播放设置", "播放模式、音质与缓存", Icons.Default.Equalizer)
        SettingsRow("歌词设置", "支持导入 LRC、逐行同步显示", Icons.Default.Subtitles)
        Spacer(Modifier.height(18.dp)); Text("外观", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("跟随系统主题"); Text("自动切换深色和浅色", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked = followSystem, onCheckedChange = onFollow) }
        if (!followSystem) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("深色模式", Modifier.weight(1f)); Switch(checked = manualDark, onCheckedChange = onDark) }
    }
    if (showSources) SourceManagerDialog(sources, sourceMessage, onImportSource, onCheckSources, onDeleteSource) { showSources = false }
}

@Composable
private fun SourceManagerDialog(sources: List<MusicSource>, message: String, onImport: () -> Unit, onCheck: () -> Unit, onDelete: (MusicSource) -> Unit, onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, title = { Text("音源管理") },
        text = { Column(Modifier.fillMaxWidth()) {
            Text(message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(4.dp)); Text("导入 JSON") }
                Button(onClick = onCheck, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Speed, null); Spacer(Modifier.width(4.dp)); Text("测速") }
            }
            Spacer(Modifier.height(8.dp))
            if (sources.isEmpty()) Text("尚未添加音源。导入你有权使用的服务配置。", fontSize = 13.sp)
            else LazyColumn(Modifier.heightIn(max = 280.dp)) { items(sources, key = { it.id }) { source ->
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(source.name, fontWeight = FontWeight.SemiBold); Text("${source.status}${source.latencyMs?.let { " · ${it} ms" } ?: ""}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = { onDelete(source) }) { Icon(Icons.Default.DeleteOutline, "删除音源") }
                }
            } }
            Spacer(Modifier.height(6.dp)); Text("安全说明：仅导入数据型 JSON 配置；不会执行音源包中的 JavaScript。各类洛雪插件格式需逐个适配。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } }, confirmButton = { TextButton(onClick = onClose) { Text("完成") } })
}

@Composable
private fun PlayerSheet(
    title: String, artist: String, artworkUrl: String?, playing: Boolean, onPlay: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    lyricLines: List<LyricLine>, lyricMessage: String, onImportLyrics: () -> Unit, onMatchLyrics: () -> Unit,
    playbackPosition: () -> Long, durationMs: Long, shuffleEnabled: Boolean, repeatMode: Int,
    queueItems: List<Pair<String, String>>, onSeekTo: (Long) -> Unit, onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit, onJumpToQueueItem: (Int) -> Unit, onClose: () -> Unit
) {
    var positionMs by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var lyricOffsetMs by remember(title, artist) { mutableLongStateOf(0L) }
    val activeIndex = LrcTimeline.activeIndex(lyricLines, positionMs, lyricOffsetMs)
    val lyricListState = androidx.compose.foundation.lazy.rememberLazyListState()
    val rotation by androidx.compose.animation.core.rememberInfiniteTransition(label = "vinyl").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(12000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ), label = "vinylRotation"
    )
    LaunchedEffect(playing, title) {
        while (true) {
            if (!dragging) positionMs = playbackPosition().coerceAtLeast(0L)
            kotlinx.coroutines.delay(250)
        }
    }
    LaunchedEffect(activeIndex, showLyrics) { if (showLyrics && activeIndex >= 0) lyricListState.animateScrollToItem(activeIndex) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, "收起播放器") }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("正在播放", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.5.sp)
                        Text("MUSIC ONE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    IconButton(onClick = { showQueue = !showQueue }) { Icon(Icons.Default.QueueMusic, "播放队列") }
                }
                if (showQueue) {
                    Card(Modifier.fillMaxWidth().heightIn(max = 210.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("接下来播放 · ${queueItems.size} 首", fontWeight = FontWeight.Bold)
                            LazyColumn(Modifier.heightIn(max = 165.dp)) {
                                items(queueItems.size) { index ->
                                    Row(Modifier.fillMaxWidth().clickable { onJumpToQueueItem(index); showQueue = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${index + 1}", Modifier.width(28.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Column(Modifier.weight(1f)) { Text(queueItems[index].first, maxLines = 1, fontWeight = FontWeight.SemiBold); Text(queueItems[index].second, maxLines = 1, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                if (showLyrics) {
                    Spacer(Modifier.weight(0.3f))
                    Text(lyricMessage, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { lyricOffsetMs = (lyricOffsetMs - 500L).coerceIn(-10_000L, 10_000L) }) { Text("歌词慢 0.5 秒") }
                        Text("${if (lyricOffsetMs > 0) "+" else ""}${"%.1f".format(lyricOffsetMs / 1000.0)}s", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { lyricOffsetMs = (lyricOffsetMs + 500L).coerceIn(-10_000L, 10_000L) }) { Text("歌词快 0.5 秒") }
                        TextButton(onClick = { lyricOffsetMs = 0L }) { Text("重置") }
                    }
                    if (lyricLines.isEmpty()) Text("暂无歌词。可匹配在线歌词或导入 LRC。", modifier = Modifier.padding(16.dp))
                    else LazyColumn(state = lyricListState, modifier = Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        items(lyricLines.size) { index ->
                            val line = lyricLines[index]
                            Text(line.text.ifBlank { "♪" }, modifier = Modifier.fillMaxWidth().clickable { onSeekTo(LrcTimeline.playbackPositionForLine(line, lyricOffsetMs)); positionMs = LrcTimeline.playbackPositionForLine(line, lyricOffsetMs) }.padding(vertical = 12.dp),
                                color = if (index == activeIndex && activeIndex >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (index == activeIndex && activeIndex >= 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = if (index == activeIndex && activeIndex >= 0) 20.sp else 15.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                } else {
                    Spacer(Modifier.weight(0.35f))
                    Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(horizontal = 14.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = if (playing) rotation else 0f }.clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            if (!artworkUrl.isNullOrBlank()) {
                                AsyncImage(model = artworkUrl, contentDescription = "专辑封面", modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                            } else {
                                Icon(Icons.Default.Album, null, Modifier.size(110.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Box(Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.background.copy(alpha = 0.88f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        }
                    }
                    Spacer(Modifier.weight(0.3f))
                }
                Text(title.ifBlank { "尚未播放" }, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(artist.ifBlank { "MUSIC ONE" }, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Spacer(Modifier.height(18.dp))
                Slider(value = if (durationMs > 0L) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f,
                    onValueChange = { value -> dragging = true; positionMs = (value * durationMs).toLong() },
                    onValueChangeFinished = { onSeekTo(positionMs); dragging = false }, enabled = durationMs > 0L)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatPlaybackTime(positionMs), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatPlaybackTime(durationMs), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleShuffle) { Icon(Icons.Default.Shuffle, "随机播放", tint = if (shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "上一首", Modifier.size(38.dp)) }
                    FilledIconButton(onClick = onPlay, modifier = Modifier.size(68.dp)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "播放或暂停", Modifier.size(38.dp)) }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "下一首", Modifier.size(38.dp)) }
                    IconButton(onClick = onCycleRepeat) {
                        Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                            "循环模式：${when (repeatMode) { Player.REPEAT_MODE_ONE -> "单曲循环"; Player.REPEAT_MODE_ALL -> "列表循环"; else -> "关闭" }}",
                            tint = if (repeatMode == Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    TextButton(onClick = { showLyrics = !showLyrics }) { Icon(Icons.Default.Subtitles, null); Spacer(Modifier.width(5.dp)); Text(if (showLyrics) "封面" else "歌词") }
                    TextButton(onClick = onMatchLyrics) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(5.dp)); Text("匹配歌词") }
                    TextButton(onClick = onImportLyrics) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(5.dp)); Text("导入 LRC") }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

private fun formatPlaybackTime(milliseconds: Long): String {
    if (milliseconds <= 0L) return "0:00"
    val totalSeconds = milliseconds / 1000L
    return "${totalSeconds / 60}:${(totalSeconds % 60).toString().padStart(2, '0')}"
}

@Composable
private fun MiniPlayer(title: String, playing: Boolean, onPlay: () -> Unit, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).clickable { onOpen() }.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE7D5D5)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Ink) }
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1); Text("MUSIC ONE", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        IconButton(onClick = onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
    }
}

@Composable private fun SectionTitle(title: String, action: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold); TextButton(onClick = onClick) { Text(action) } } }
@Composable private fun SongRow(title: String, artist: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(artist, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Icon(Icons.Default.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun SettingsRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } }
