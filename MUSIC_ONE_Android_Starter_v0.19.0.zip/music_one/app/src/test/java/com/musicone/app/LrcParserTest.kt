package com.musicone.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {
    @Test
    fun parsesSingleTimestampAndCentiseconds() {
        val lines = LrcParser.parse("[00:01.25]hello\n[00:02.5]world")
        assertEquals(listOf(LyricLine(1_250L, "hello"), LyricLine(2_500L, "world")), lines)
    }

    @Test
    fun parsesMultipleTimestampsAndSortsChronologically() {
        val lines = LrcParser.parse("[00:03.00][00:01.00]repeat")
        assertEquals(listOf(LyricLine(1_000L, "repeat"), LyricLine(3_000L, "repeat")), lines)
    }

    @Test
    fun lyricOffsetChangesHighlightAndTapSeekPosition() {
        val lines = listOf(LyricLine(1_000L, "one"), LyricLine(2_000L, "two"))
        assertEquals(0, LrcTimeline.activeIndex(lines, 700L, 500L))
        assertEquals(1, LrcTimeline.activeIndex(lines, 1_600L, 500L))
        assertEquals(1_500L, LrcTimeline.playbackPositionForLine(lines[1], 500L))
        assertEquals(2_500L, LrcTimeline.playbackPositionForLine(lines[1], -500L))
    }

    @Test
    fun ignoresInvalidSecondsAndMetadata() {
        val lines = LrcParser.parse("[ar:Artist]\n[00:75.00]bad\n[01:02.003]good")
        assertEquals(1, lines.size)
        assertEquals(LyricLine(62_003L, "good"), lines.first())
        assertTrue(lines.first().text.isNotBlank())
    }
}
