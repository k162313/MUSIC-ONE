# MUSIC ONE — Android starter / playback milestone

MUSIC ONE is a Kotlin + Jetpack Compose Android music player project.

## 0.19.0 稳定性与数据边界加固（源码更新）
- 修复播放队列恢复时的索引偏移：遇到损坏/缺失条目时，恢复位置会映射到原始队列对应项，而不是直接套用压缩后列表的索引。
- 恢复播放队列前限制 checkpoint JSON 大小、条目数和元数据字段长度，避免异常偏好数据构造超大队列。
- 收藏、最近播放、歌单和播放次数增加读取/写入上限；限制歌单数量、单歌单曲目数及单条记录字段长度。
- 音源配置导入限制文件大小、音源数量和配置字段长度；新导入/更新的音源优先保留，避免已有列表已满时新音源被静默挤掉。
- 网络响应读取改为按 UTF-8 字节数硬限制；音源健康检查只读取有限响应前缀，避免无意义地下载整个响应体。
- 移除当前源码未使用的 Room 与 DataStore 依赖，减少不必要的依赖体积。

**验证边界：** 已进行源码静态检查与 ZIP 完整性检查；当前环境没有 Android SDK/Gradle，未执行 APK 编译、CI 或真机测试。以上是源码层更新，不代表已通过 Android 构建。

## Current implementation
- Apple Music-inspired Compose shell with Home / Browse / Library / Me tabs.
- Light/dark theme follows the system by default, with a manual override.
- Reads on-device audio through MediaStore after requesting the Android audio permission.
- Plays selected local tracks through AndroidX Media3 ExoPlayer.
- Playback is hosted in a `MediaSessionService`, enabling background playback and system media controls.
- Imports standard `.lrc` lyric files, supports automatic matching through a user-configured HTTPS lyric API, caches matched LRC locally, and highlights/auto-scrolls the active line against the Media3 playback position.

## Build
Open this folder in Android Studio (recent stable version), allow Gradle sync, then run the `app` configuration on an Android device (minSdk 26).

The project does not currently include a Gradle wrapper. Android Studio can import it using the installed Gradle tooling, or you can generate a wrapper from a local Gradle installation.

## Not yet implemented
- Online provider/source adapter runtime and import UI.
- Validation of compatibility with individual 洛雪 JSON source dialects (formats vary between source ecosystems and versions).
- Source health checks and automatic fallback between permitted providers.
- A bundled lyric catalog/service (automatic matching requires the user to configure an authorized provider endpoint).
- Playlists persistence, user accounts, cloud sync, and production backend.

Online sources must be used only where the user has permission and the provider's terms and copyright allow it. No third-party music catalog or unauthorized resolver is bundled.

## Source manager milestone (0.3 development)
- Added JSON source import from Android's document picker.
- Added a persistent local source list, source removal, HTTP health/latency checks, and fastest-healthy-source recommendation.
- Import is intentionally data-only and HTTPS-only. The app does not execute JavaScript from source bundles. 洛雪/LX Music source ecosystems can use executable JS plugins and have multiple schema variants; those are **not** automatically compatible yet. Individual permitted providers need explicit adapters before online search/stream resolution can work.
- Example descriptor: `docs/source-format.example.json`.

### MUSIC ONE source JSON format
```json
{
  "version": 1,
  "sources": [
    { "name": "My licensed service", "baseUrl": "https://service.example/api", "pingUrl": "https://service.example/health" }
  ]
}
```
`pingUrl` is optional and defaults to `baseUrl`. Only HTTPS URLs are accepted. Health checks measure endpoint reachability; they do not verify that a provider can legally or technically resolve playable tracks.

## Online provider search/play milestone (0.4 development)
- Added a generic, data-only JSON API adapter for providers the user is authorized to access.
- Browse now searches all enabled sources that define `searchUrlTemplate`, parses configured JSON paths/fields, and displays returned tracks.
- Selecting a result hands its HTTPS stream URL to Media3 for playback.
- Search runs on an IO dispatcher; response size and result count are bounded.
- No public/unauthorized catalog, scraping resolver, or executable JavaScript plugin is bundled. A provider must document/permit its API and stream URLs.

Example source descriptor is in `docs/source-format.example.json`. Fields:
- `searchUrlTemplate`: HTTPS GET URL containing `{query}`; MUSIC ONE URL-encodes the keyword.
- `itemsPath`: dot path to the result array, e.g. `data.items`.
- `titleField`, `artistField`, `streamField`: dot paths inside each result object. Array indices are supported, e.g. `artists.0.name`.

This generic adapter is intentionally not a universal 洛雪/LX Music JS plugin runtime. Different source ecosystems use executable scripts and different protocols, so individual permitted source types require explicit adapters. The app currently requires the resolved stream URL itself to be HTTPS.

## Verification status
The source project was updated, but this environment does not have an Android SDK/Gradle build tool available, so an APK build and device playback test have **not** been performed. Open the project in Android Studio and run Gradle sync/build to verify against your installed SDK.


## Lyrics milestone (0.5 development)
- Added `.lrc` file import through Android's document picker.
- Parses `[mm:ss]`, `[mm:ss.f]`, `[mm:ss.ff]`, and `[mm:ss.fff]` timestamps; multiple timestamps on one line are supported.
- The player view can show/hide lyrics, highlights the current line using the active Media3 playback position, and scrolls the current line into view.
- This is synchronized local-LRC support, not yet automatic network lyric search. Automatic matching needs a documented/authorized lyric API or a user-configured lyric provider, plus track metadata matching and cache rules.

## Smart source fallback milestone (0.6 development)
- Search results are ranked with the last successfully playing provider first, then by measured provider latency.
- When Media3 reports a playback error for an online result, MUSIC ONE tries another configured result with the same normalized track title and compatible artist metadata.
- Each stream URL is attempted at most once per manual play action; fallback stops after the available matching alternatives are exhausted.
- Successful playback remembers the provider name locally for future ranking. This is a preference hint, not a guarantee that a provider will remain available.
- Local-file playback errors are not intercepted by online source fallback.
- Fallback only uses HTTPS stream URLs returned by the user's explicitly configured provider APIs. It does not scrape catalogs or bypass provider access controls.

## Verification status for 0.6
- Source-level implementation added. Android SDK/Gradle is not installed in this environment, so compilation and device-level fallback behavior remain unverified.


## Personal library milestone (0.7 development)
- Added persistent favorites, recently played history, and user-created playlists using a versioned JSON record in Android SharedPreferences.
- Users can favorite local songs and online search results, create and delete playlists, and add songs to playlists from the local library or online search results.
- Recently played entries are recorded when playback is requested. The recent list is capped at 100 entries; favorites are capped at 500.
- Saved local tracks are resolved against the current MediaStore scan. Saved online entries retain the HTTPS stream URL supplied by the configured provider; playback validates HTTPS before attempting it. Provider URLs can expire, so users may need to search again if a saved online URL becomes invalid.
- Data remains on this device. There is no account, cloud backup, cross-device sync, playlist export, or collaborative playlist feature in this milestone.

## Verification status for 0.7
- Updated project source and version metadata to 0.7.0. This environment has no Android SDK or Gradle installation, so Android compilation, UI instrumentation, and playback tests have not been run. Import the project in Android Studio and run Gradle sync/build before installing on a device.


## Automatic lyric matching and cache milestone (0.8 development)
- Added optional `lyricUrlTemplate` and `lyricField` properties to the data-only source descriptor. Templates support `{query}` (URL-encoded title + artist), `{title}`, and `{artist}` placeholders and must resolve to HTTPS.
- The player automatically looks up lyrics when a local or online track starts, and also offers a manual “匹配歌词” action.
- Provider responses may be raw LRC text or JSON; `lyricField` is a dot path to the LRC text (for example `data.lrc`). Only valid timestamped LRC is accepted.
- Successful matches are cached on-device by normalized title + artist. Existing manual `.lrc` import remains available.
- No lyric service is bundled. Users must configure an authorized provider endpoint; each provider's API terms and copyright permissions apply.

## Verification status for 0.8
- Added source descriptor parsing, HTTPS lyric fetching, LRC validation, local cache, and player controls. Android SDK/Gradle are not installed in this environment, so Android compilation and device/network tests have not been run. The example API URL is illustrative and is not a live service.


## Player experience milestone (0.9 development)
- Replaced the compact player dialog with an immersive full-screen player surface.
- Added a rotating circular album-art presentation while playback is active, with a neutral fallback when artwork is unavailable.
- Local MediaStore scans now retain the album ID and provide the standard Android album-art content URI as media metadata.
- Online provider search results can optionally expose an HTTPS artwork URL via `artworkField` (defaults to `artwork`); non-HTTPS artwork URLs are ignored.
- Added a seek slider with elapsed/total time, shuffle toggle, repeat-off / repeat-one / repeat-all cycling, and an expandable playback queue with direct track selection.
- Added Coil Compose for loading local content URIs and provider-supplied HTTPS cover images.
- The Media3 media metadata continues to supply title, artist, album and artwork URI for system media controls/lock-screen surfaces; actual lock-screen artwork rendering depends on Android/OEM behavior and image availability.

## Verification status for 0.9
- Source-level changes added. Android SDK/Gradle are not installed in this environment, so Gradle compilation, emulator tests, lock-screen verification, and real-device playback remain unverified.


## Release hardening milestone (0.10.0 development)
- Updated Android version metadata to `0.10.0` / versionCode `10`; this is a development build, not a production release.
- Added JVM unit tests for LRC timestamp parsing, multiple timestamps, chronological ordering, and invalid seconds.
- Added a GitHub Actions workflow that installs JDK 17 + Android SDK 36, runs unit tests, assembles a debug APK, and uploads the APK as a workflow artifact.
- Added `.gitignore` rules for local Gradle/Android Studio files and generated APK/build output.

## Build and verification
- Local build: open the `music_one` folder in Android Studio, sync Gradle, then run `:app:testDebugUnitTest` and `:app:assembleDebug`.
- CI build: push this folder to a GitHub repository; the `Android CI` workflow runs on push/PR or via manual workflow dispatch. Download `music-one-debug-apk` from the successful workflow run's Artifacts section.
- The GitHub workflow has been authored but has **not** been executed from this environment. The app is therefore still unverified as a whole; do not treat this source archive as a tested APK or production-ready release.
- Before publishing, complete device tests across Android versions, permissions, background playback, audio focus/headset events, source import validation, provider API terms, privacy disclosures, and Play policy review.


### V0.11.0 — 音源网络请求安全加固

- 音源测速现在只将 HTTP 2xx 视为成功，不再把 3xx 重定向误报为可用。
- 在线搜索与歌词请求禁用自动重定向，避免 HTTPS 音源静默跳转到其他目标。
- 搜索与歌词响应改为有上限的流式读取，超过限制会中止，避免先将超大响应完整载入内存。
- 以上为源码审查与静态修改；当前环境没有 Android SDK/Gradle，尚未执行 Android 编译或设备验证。


### V0.12.0 — 播放服务生命周期与音频焦点

- Playback service now enables ExoPlayer audio-focus handling, so other audio apps can be ducked/paused appropriately when MUSIC ONE starts playback and focus is abandoned when playback ends.
- Enables pause-on-audio-becoming-noisy behavior (for example, when wired headphones are unplugged).
- Releases the MediaSession before releasing its underlying ExoPlayer instance.
- This is a source-level change only; Android compilation and device behavior still require CI/device verification.

## V0.13.0 playback recovery

- The playback service checkpoints the current queue, media metadata, current item index and playback position to private app preferences.
- Checkpoints are updated on queue/item/state changes and every five seconds while playing.
- Shuffle and repeat modes are persisted and restored with the queue.
- On service recreation, the saved queue is prepared at the previous position but playback remains paused to avoid unexpected audio on app launch.
- This is best-effort recovery: Android may revoke temporary access to document-provider URIs, and remote stream URLs may expire. Such items may need to be selected or searched again.
- This source change has not been compiled or device-tested in this environment.


## Local library browsing milestone (0.14.0)
- Added local-library grouping views for songs, albums, and artists.
- Album rows use MediaStore album-art content URIs when available and show track counts; tapping an album or artist starts playback from its first matching track.
- These are browsing/grouping views over the current MediaStore scan; they do not yet create persistent album/artist pages or track-level play-count analytics.

## Verification status for 0.14.0
- Source changes and ZIP packaging were checked. Android compilation and device UI/media tests have not been run in this environment.

## V0.15.0 library improvements
- Added local-library keyword filtering across title, artist, and album metadata.
- Added persistent per-track play counters to the existing local library JSON store; older library data without counters remains readable.
- Added a `常听` library section sorted by recorded play count, and play-count labels in local song rows.
- Play counts increment when the app records a track in recent history (local and configured online tracks).
- Validation in this environment: source-level review and ZIP integrity only. Android SDK/Gradle are unavailable here, so compilation and device behavior remain unverified.


## Lyrics timing adjustment (0.16.0)
- Added an in-player lyric timing adjustment control in 500 ms increments, bounded to +/-10 seconds, with a reset action.
- Highlight synchronization and tapping a lyric line to seek both account for the active offset. Positive offsets move lyric timing earlier relative to playback; negative offsets move it later.
- Added unit coverage for offset-aware highlighting and line seeking. The adjustment currently applies for the open player session and resets when the player is reopened or the track changes.
- Android compilation and device behavior still require CI/device verification.


## System media integration milestone (0.17.0 development)
- Added a MediaSession session-activity PendingIntent that opens the MUSIC ONE player when the user taps the system media surface/notification, using singleTop/clearTop launch flags to avoid stacking duplicate activity instances.
- Hardened playback-state restoration by validating the persisted repeat mode before applying it to Media3.
- Existing media metadata (title, artist, album and artwork URI) remains the source for Android system media controls and lock-screen surfaces. Synchronized lyric text is not exposed as a standardized lock-screen lyric view because Android/OEM media surfaces do not provide a universal lyrics display contract.
- Source-level changes only; Android SDK/Gradle are unavailable in this environment, so compilation and device verification have not been performed.


## V0.18.0 — 播放队列检查点修复

- 清空播放队列时同步删除持久化检查点，避免下次启动时恢复已经被用户清除的旧队列。
- 保存检查点时逐项验证媒体 URI；单个异常队列项不再中断整个队列的保存。
- 对持久化队列数量、媒体 URI 和元数据字段增加上限，降低异常/过大数据导致的本地存储膨胀风险。
- 修正恢复索引边界，并清理音源搜索中重复的 HTTPS 校验语句。
- 本次为源码审查后的修复；当前执行环境没有 Android SDK/Gradle，尚未完成 Android 编译或设备验证。
